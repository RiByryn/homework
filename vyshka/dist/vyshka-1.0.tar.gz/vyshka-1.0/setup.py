from setuptools import setup

setup(
    name='vyshka',
    version='1.0',
    description='Tool for generating Vyshka calendar',
    author='Liga Indigo',
    author_email='liga.indigo@gmail.com',
    url='ligaindigo.ru',
    py_modules=['vyshka'],
)